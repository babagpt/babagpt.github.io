// Central data management for easy updates
export const siteConfig = {
  name: "Alexie Smith",
  title: "Alexie Smith - Full Stack Developer",
  description: "Full-stack developer crafting beautiful and performant web experiences",
  email: "alexiesd090@gmail.com",
  location: "Remote",
  social: {
    github: "https://github.com/babaaslex",
    linkedin: "#",
    email: "mailto:alexiesd090@gmail.com"
  }
};

// Re-export JSON data with type safety
export { default as projects } from '../data/projects.json';
export { default as skills } from '../data/skills.json';
