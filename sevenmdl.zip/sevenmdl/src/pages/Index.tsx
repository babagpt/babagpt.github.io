import EnvironmentBadge from "@/components/EnvironmentBadge";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import About from "@/components/About";
import CareerTimeline from "@/components/CareerTimeline";
import ProjectCategories from "@/components/ProjectCategories";
import SkillsEnhanced from "@/components/SkillsEnhanced";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";


const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <Hero />
      <About />
      <CareerTimeline />
      <ProjectCategories />
      <SkillsEnhanced />
      <Contact />
      <Footer />
      <EnvironmentBadge />
    </div>
  );
};

export default Index;
