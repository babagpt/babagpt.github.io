const About = () => {
  return (
    <section
      id="about"
      className="flex items-center justify-center min-h-screen px-6 py-20"
    >
      <div className="w-full max-w-5xl">
        <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">
          About Me
        </h2>

        <div className="bg-card rounded-lg p-8 shadow-[var(--shadow-card)] border border-border mx-auto max-w-prose space-y-6">
          <p className="text-lg text-muted-foreground leading-relaxed">
            Hey, I'm <span className="font-semibold text-foreground">Alexie Smith</span> — a self-taught
            full-stack developer who enjoys turning ideas into functional, secure, and
            well-designed software. I started small, coding entirely on my Android phone
            using Termux, and over time, that hands-on learning shaped how I approach building
            reliable systems today.
          </p>

          <p className="text-lg text-muted-foreground leading-relaxed">
            My first serious build was <span className="font-medium text-foreground">Secure File Server</span>,
            a Node.js backend that helped me understand authentication, data flow, and modular structure.
            From there, I created <span className="font-medium text-foreground">Link Share</span> —
            a complete file-sharing app with expiring links and an admin dashboard — all developed and tested
            through Termux and GitHub Codespaces.
          </p>

          <p className="text-lg text-muted-foreground leading-relaxed">
            Later came <span className="font-medium text-foreground">Marketplace V1.10</span>, my take on a
            product listing and order management system, followed by
            <span className="font-medium text-foreground"> QuickBill Desk</span>, a lightweight offline
            invoicing tool for small businesses. Each project taught me something new — from scaling backend APIs
            to improving frontend design and user flow.
          </p>

          <p className="text-lg text-muted-foreground leading-relaxed">
            Working inside limited but creative environments like Termux and Codespaces taught me to
            value simplicity, efficiency, and adaptability. I love building tools that make everyday tasks
            easier, secure, and accessible — no matter where they run.
          </p>

          <p className="text-lg text-muted-foreground leading-relaxed">
            When I’m not coding, I’m usually exploring new technologies, refining my existing projects,
            or improving my workflow setups. I believe every challenge is an opportunity to learn —
            and every small step in code adds up to something great.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
