import { Github, Linkedin, Mail } from "lucide-react";
import { toast } from "sonner";

export default function Footer() {
  return (
    <footer className="py-8 text-center border-t border-border">
      <div className="flex justify-center space-x-6 mb-4">
        <a
          href="https://github.com/babaaslex"
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-primary transition-colors"
        >
          <Github className="h-6 w-6" />
        </a>

        <button
          onClick={() => toast("LinkedIn profile coming soon!")}
          className="text-muted-foreground hover:text-primary transition-colors"
        >
          <Linkedin className="h-6 w-6" />
        </button>

        <a
          href="mailto:alexiesd090@gmail.com"
          className="text-muted-foreground hover:text-primary transition-colors"
        >
          <Mail className="h-6 w-6" />
        </a>
      </div>

      <p className="text-sm text-muted-foreground">
        © {new Date().getFullYear()} Alexie Smith. All rights reserved.
      </p>
    </footer>
  );
}
