import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "./LoadingSpinner";

interface TimelineEvent {
  period: string;
  title: string;
  projects: number;
  technologies: string[];
  highlights: string[];
}

interface CareerData {
  timeline: TimelineEvent[];
  statistics: {
    totalProjects: number;
    yearsExperience: number;
    technologiesUsed: number;
    productionDeployments: number;
  };
}

const CareerTimeline = () => {
  const [careerData, setCareerData] = useState<CareerData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/data/career.json')
      .then(res => res.json())
      .then((data: CareerData) => {
        setCareerData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading career data:', err);
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <section id="career" className="py-20 bg-secondary/20">
      <div className="container mx-auto max-w-6xl px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
          Career Journey
        </h2>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary">{careerData?.statistics.totalProjects}+</div>
              <div className="text-muted-foreground">Projects</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary">{careerData?.statistics.yearsExperience}+</div>
              <div className="text-muted-foreground">Years Experience</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary">{careerData?.statistics.technologiesUsed}+</div>
              <div className="text-muted-foreground">Technologies</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary">{careerData?.statistics.productionDeployments}</div>
              <div className="text-muted-foreground">Deployments</div>
            </CardContent>
          </Card>
        </div>

        {/* Timeline */}
        <div className="space-y-8">
          {careerData?.timeline.map((event, index) => (
            <Card key={index} className="relative">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                  <Badge variant="outline" className="text-lg px-4 py-2">
                    {event.period}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-primary/20">
                    {event.projects} Projects
                  </Badge>
                  <div className="flex flex-wrap gap-1">
                    {event.technologies.map((tech, techIndex) => (
                      <Badge key={techIndex} variant="outline" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
                <ul className="space-y-2">
                  {event.highlights.map((highlight, highlightIndex) => (
                    <li key={highlightIndex} className="flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span className="text-muted-foreground">{highlight}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CareerTimeline;
