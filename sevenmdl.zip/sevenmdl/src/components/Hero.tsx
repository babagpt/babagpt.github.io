import { Github, Linkedin, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const socialLinks = [
  {
    href: "https://github.com/babaaslex",
    icon: Github,
    label: "GitHub"
  },
  {
    href: "#",
    icon: Linkedin,
    label: "LinkedIn",
    onClick: () => toast("LinkedIn profile coming soon!")
  },
  {
    href: "mailto:alexiesd090@gmail.com",
    icon: Mail,
    label: "Email"
  }
];

// Smooth scroll function
const scrollToSection = (sectionId: string) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }
};

export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center text-center space-y-4 xs:space-y-6 px-4 xs:px-6">
      <h1 className="text-4xl xs:text-5xl md:text-6xl lg:text-7xl font-bold text-primary leading-tight">
        Hi, I'm <span className="block mt-2">Alexie Smith</span>
      </h1>
      
      <p className="max-w-xs xs:max-w-sm sm:max-w-md md:max-w-2xl text-base xs:text-lg md:text-xl text-muted-foreground leading-relaxed">
        A passionate full-stack developer focused on building secure, modern, and scalable web applications. 
        I specialize in React, Node.js, and TypeScript, with a strong focus on simplicity and reliability.
      </p>

      <div className="flex flex-col xs:flex-row gap-4 xs:gap-6 mt-8">
        <Button 
          size="lg" 
          className="text-base px-8"
          onClick={() => scrollToSection('projects')}
        >
          View My Work
        </Button>
        <Button 
          variant="outline" 
          size="lg" 
          className="text-base px-8"
          onClick={() => scrollToSection('contact')}
        >
          Get In Touch
        </Button>
      </div>

      <div className="flex space-x-4 xs:space-x-6 mt-12">
        {socialLinks.map((link, index) => {
          if (link.onClick) {
            return (
              <button
                key={index}
                onClick={link.onClick}
                className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
                aria-label={link.label}
              >
                <link.icon className="h-6 w-6 xs:h-7 xs:w-7 md:h-8 md:w-8" />
              </button>
            );
          }
          return (
            <a
              key={index}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
              aria-label={link.label}
            >
              <link.icon className="h-6 w-6 xs:h-7 xs:w-7 md:h-8 md:w-8" />
            </a>
          );
        })}
      </div>
    </section>
  );
}
