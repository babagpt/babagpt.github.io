import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Github, ExternalLink } from "lucide-react";
import { LoadingSpinner } from "./LoadingSpinner";

interface Project {
  id: number;
  title: string;
  shortDescription: string;
  description: string;
  technologies: string[];
  image: string;
  placeholder: string;
  github: string;
  live: string;
  featured: boolean;
  category: string;
  status: string;
}

interface ProjectsData {
  projects: Project[];
}

const Projects = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timestamp = new Date().getTime();
    fetch(`/data/projects.json?t=${timestamp}`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to load projects');
        return res.json();
      })
      .then((data: ProjectsData) => {
        setProjects(data.projects.filter(project => project.featured));
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading projects:', err);
        setError('Failed to load projects');
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="text-center py-8 text-destructive">{error}</div>;

  return (
    <section id="projects" className="py-16 xs:py-20 px-4 xs:px-6 bg-secondary/30">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-3xl xs:text-4xl md:text-5xl font-bold mb-8 xs:mb-12 text-center">
          Featured Projects
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 xs:gap-6">
          {projects.map((project) => (
            <Card 
              key={project.id} 
              className="bg-card border-border hover:shadow-[var(--shadow-glow)] transition-all duration-300 group flex flex-col h-full"
            >
              <CardHeader className="p-0">
                <div className="aspect-video bg-secondary/50 rounded-t-lg overflow-hidden">
                  <img 
                    src={project.image}  // ✅ Use the actual image URL
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      // Fallback to placeholder if image fails to load
                      e.currentTarget.src = project.placeholder;
                    }}
                  />
                </div>
              </CardHeader>
              
              <CardContent className="p-4 xs:p-6 flex-1">
                <div className="flex items-start justify-between mb-2">
                  <CardTitle className="text-lg xs:text-xl">{project.title}</CardTitle>
                  <Badge variant="outline" className="text-xs">
                    {project.category}
                  </Badge>
                </div>
                
                <CardDescription className="text-sm xs:text-base text-muted-foreground line-clamp-3 mb-4">
                  {project.shortDescription}
                </CardDescription>
                
                <div className="flex flex-wrap gap-1 xs:gap-2">
                  {project.technologies.slice(0, 4).map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs bg-secondary text-secondary-foreground">
                      {tech}
                    </Badge>
                  ))}
                  {project.technologies.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{project.technologies.length - 4}
                    </Badge>
                  )}
                </div>
              </CardContent>
              
              <CardFooter className="gap-2 p-4 xs:p-6 pt-0">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-border hover:bg-secondary flex-1"
                  asChild
                >
                  <a href={project.github} target="_blank" rel="noopener noreferrer">
                    <Github className="h-4 w-4 mr-2" />
                    Code
                  </a>
                </Button>
                <Button 
                  size="sm"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground flex-1"
                  asChild
                >
                  <a href={project.live} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Live Demo
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
