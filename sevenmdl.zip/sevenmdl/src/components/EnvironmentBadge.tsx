import { Terminal, Smartphone } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const EnvironmentBadge = () => {
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-2">
      <Badge variant="secondary" className="flex items-center gap-2 py-2">
        <Terminal className="h-3 w-3" />
        Termux Developer
      </Badge>
      <Badge variant="secondary" className="flex items-center gap-2 py-2">
        <Smartphone className="h-3 w-3" />
        Mobile-First Workflow
      </Badge>
    </div>
  );
};

export default EnvironmentBadge;
