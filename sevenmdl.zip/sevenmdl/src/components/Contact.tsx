import { Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Contact() {
  return (
    <section
      id="contact"
      className="py-20 text-center flex flex-col items-center space-y-6"
    >
      <h2 className="text-4xl font-bold mb-4">Get In Touch</h2>
      <p className="max-w-lg text-muted-foreground mb-8">
        Whether you have a project in mind, a question, or just want to say hello —
        feel free to reach out! I’m always open to connecting with new people and ideas.
      </p>

      <div className="flex flex-col items-center space-y-2">
        <p className="text-lg font-medium text-foreground">
          📍 Remote
        </p>

        <a
          href="mailto:alexiesd090@gmail.com"
          className="text-primary hover:underline flex items-center gap-2"
        >
          <Mail className="h-5 w-5" /> alexiesd090@gmail.com
        </a>
      </div>

      <Button asChild className="mt-6">
        <a href="mailto:alexiesd090@gmail.com">Send Me an Email</a>
      </Button>
    </section>
  );
}
