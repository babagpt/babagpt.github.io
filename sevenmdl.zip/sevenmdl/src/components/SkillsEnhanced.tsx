import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "./LoadingSpinner";

interface SkillItem {
  name: string;
  level: number;
  years: number;
  projects: number;
  expertise: string;
}

interface SkillCategory {
  category: string;
  items: SkillItem[];
}

const SkillsEnhanced = () => {
  const [skills, setSkills] = useState<SkillCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/data/skills-enhanced.json')
      .then(res => res.json())
      .then((data: { categories: SkillCategory[] }) => {
        setSkills(data.categories);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading skills:', err);
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <section id="skills-enhanced" className="py-20 bg-secondary/20">
      <div className="container mx-auto max-w-6xl px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
          Technical Expertise
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {skills.map((skillGroup) => (
            <Card key={skillGroup.category} className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">
                  {skillGroup.category}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillGroup.items.map((skill) => (
                    <div key={skill.name} className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <span className="font-medium text-foreground">{skill.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {skill.expertise}
                          </Badge>
                        </div>
                        <div className="text-right text-sm text-muted-foreground">
                          <div>{skill.years} {skill.years === 1 ? 'year' : 'years'}</div>
                          <div>{skill.projects} projects</div>
                        </div>
                      </div>
                      
                      <div className="w-full bg-secondary rounded-full h-3">
                        <div 
                          className="bg-primary rounded-full h-3 transition-all duration-1000 ease-out"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                      
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Beginner</span>
                        <span>Expert</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsEnhanced;
