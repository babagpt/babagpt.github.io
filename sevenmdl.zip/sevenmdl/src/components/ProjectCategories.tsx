import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Github, ExternalLink, FolderOpen } from "lucide-react";
import { LoadingSpinner } from "./LoadingSpinner";

interface Project {
  id: number;
  title: string;
  versions: string[];
  description: string;
  technologies: string[];
  features: string[];
  github: string;
  demo?: string;
  status: string;
  complexity: string;
}

interface ProjectCategory {
  name: string;
  icon: string;
  projects: Project[];
}

const ProjectCategories = () => {
  const [categories, setCategories] = useState<ProjectCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState(0);

  useEffect(() => {
    fetch('/data/projects-enhanced.json')
      .then(res => res.json())
      .then((data: { categories: ProjectCategory[] }) => {
        setCategories(data.categories);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading projects:', err);
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <section id="projects-enhanced" className="py-20">
      <div className="container mx-auto max-w-6xl px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center">
          Project Portfolio
        </h2>
        <p className="text-xl text-muted-foreground text-center mb-12 max-w-2xl mx-auto">
          A comprehensive showcase of my work across full-stack development, security tools, and automation systems
        </p>

        {/* Category Navigation */}
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {categories.map((category, index) => (
            <Button
              key={index}
              variant={activeCategory === index ? "default" : "outline"}
              onClick={() => setActiveCategory(index)}
              className="flex items-center gap-2"
            >
              <span>{category.icon}</span>
              {category.name}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {categories[activeCategory]?.projects.map((project) => (
            <Card key={project.id} className="group hover:shadow-[var(--shadow-glow)] transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FolderOpen className="h-5 w-5 text-primary" />
                    {project.title}
                  </CardTitle>
                  <Badge variant={
                    project.complexity === 'Expert' ? 'destructive' :
                    project.complexity === 'Advanced' ? 'default' : 'outline'
                  }>
                    {project.complexity}
                  </Badge>
                </div>
                <div className="flex flex-wrap gap-1">
                  {project.versions.map((version, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {version}
                    </Badge>
                  ))}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{project.description}</p>
                
                <div>
                  <h4 className="text-sm font-semibold mb-2">Key Features:</h4>
                  <ul className="space-y-1">
                    {project.features.slice(0, 3).map((feature, index) => (
                      <li key={index} className="text-xs text-muted-foreground flex items-start gap-1">
                        <span className="text-primary mt-1">•</span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-wrap gap-1">
                  {project.technologies.slice(0, 4).map((tech, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                  {project.technologies.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{project.technologies.length - 4}
                    </Badge>
                  )}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" asChild className="flex-1">
                    <a href={project.github} target="_blank" rel="noopener noreferrer">
                      <Github className="h-4 w-4 mr-1" />
                      Code
                    </a>
                  </Button>
                  {project.demo && (
                    <Button size="sm" asChild className="flex-1">
                      <a href={project.demo} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-1" />
                        Demo
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectCategories;
