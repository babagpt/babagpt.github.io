import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoadingSpinner } from "./LoadingSpinner";

interface SkillItem {
  name: string;
  level: number;
  years: number;
}

interface SkillCategory {
  category: string;
  icon: string;
  items: SkillItem[];
}

interface SkillsData {
  categories: SkillCategory[];
}

const Skills = () => {
  const [skills, setSkills] = useState<SkillCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/data/skills.json')
      .then(res => {
        if (!res.ok) throw new Error('Failed to load skills');
        return res.json();
      })
      .then((data: SkillsData) => {
        setSkills(data.categories);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading skills:', err);
        setError('Failed to load skills');
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <div className="text-center py-8 text-destructive">{error}</div>;

  return (
    <section id="skills" className="py-16 xs:py-20 px-4 xs:px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-3xl xs:text-4xl md:text-5xl font-bold mb-8 xs:mb-12 text-center">
          Skills & Technologies
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 xs:gap-6">
          {skills.map((skillGroup) => (
            <Card 
              key={skillGroup.category}
              className="bg-card border-border hover:border-primary/50 transition-colors h-full"
            >
              <CardHeader>
                <CardTitle className="text-xl text-primary flex items-center gap-2">
                  <span>{skillGroup.icon}</span>
                  {skillGroup.category}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {skillGroup.items.map((skill) => (
                    <li key={skill.name} className="flex flex-col">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-foreground font-medium">{skill.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {skill.years} {skill.years === 1 ? 'year' : 'years'}
                        </span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className="bg-primary rounded-full h-2 transition-all duration-1000 ease-out"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
